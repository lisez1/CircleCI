These files are to be used with Gemalto (Safenet) HSM Client version 6.2.2.
libLunaAPI.so
 - MD5 = 319d60030a350e2d7876ed6a5e19709b
 - SHA256 = 7cc115aae8beaf03e3b6f58f910015397e5e507c59b6491d59ebfcb8f1ddd954
libjcprov.so
 - MD5 = 5c7c72245b77ecbb3ef17c368675cea7
 - SHA256 = e5e53dedad2436d48e708891ff65bdde916599d4987a2500bb352bccab70396a
lunaprovider-6.2.2.jar
 - MD5 = 6ff5071eb28657d9ae07e01bb87ec18f
 - SHA256 = c90d9b32f74eea77b728991a0c596a0f8c645b64d30dfb2ab61ea9e73291df48

Instructions for configuring Key Manager
----------------------------------------
1. libLunaAPI.so and libjcprov.so must be copied to the folder with other native libraries. By default, it's /opt/keymanager/native .
2. lunaprovider-6.2.2.jar must be copied to the folder with other Symphony's jar files. By default, it's /opt/keymanager/lib.
    Important note:
    Default distribution of Key Manager already contains
    lunaprovider-5.1.2.jar file in /opt/keymanager/lib. After copying
    version 6.2.2 of lunaprovider, the old version of the jar file must be
    removed.
3. Add new 'symphony.custom.library.path' JVM parameter to environment.sh. The value of this parameter must point to a folder used in step 1 ( by default, /opt/keymanager/native ).



Instructions for configuring wenger tool
----------------------------------------
1. libLunaAPI.so and libjcprov.so must be copied to the folder with other native libraries. By default, it's <wenger_root>/native . If it does not exist, then it must be created.
2. lunaprovider-6.2.2.jar must be copied to the folder with other Symphony's jar files. By default, it's <wenger_root>/lib for wenger tool.
    Important note:
    Default distribution of Key Manager already contains
    lunaprovider-5.1.2.jar file in <wenger_root>/lib. After copying
    version 6.2.2 of lunaprovider, the old version of the jar file must be
    removed.
3. Update <wenger_root>/sbin/wenger.sh file to use a new 'symphony.custom.library.path' JVM parameter. For this modify the line that defines VMARGS variable. If the default folder <wenger_root>/native was used in step 1 then the changes should look like this:
//this is original entry
VMARGS="-DenableRemote=false -d64 -Xms2g -Xmx4g -Djava.io.tmpdir=/tmp -Dlog.dir=$LOGDIR -Djava.library.path=$CRYPTOLIBPATH"

//this is the updated line
VMARGS="-DenableRemote=false -d64 -Xms2g -Xmx4g -Djava.io.tmpdir=/tmp -Dlog.dir=$LOGDIR -Dsymphony.custom.library.path=$CRYPTOLIBPATH"
