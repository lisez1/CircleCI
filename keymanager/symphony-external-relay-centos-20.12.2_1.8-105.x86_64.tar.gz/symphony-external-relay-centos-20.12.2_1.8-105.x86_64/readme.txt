This readme.txt file provides instructions how to install Key Manager from 'tar.gz' package.

How to untar the file?
The following command will untar the package. Current user's (UID and GID) will be used to modify files' ownership permissions.
Please make sure that the same user will be used to start keymanager service.
`tar -zxvf symphony-external-relay-centos-<version>.x86_64.tar.gz --no-same-owner`

What is the content of the tar package?
Unpacking 'tar.gz' will result in the following:
- ./symphony-external-relay-centos-<version>.x86_64/bin -> contains 'relay-standalone.war'
- ./symphony-external-relay-centos-<version>.x86_64/conf -> contains default configuration files
- ./symphony-external-relay-centos-<version>.x86_64/gemalto_jsp_6.2.2 -> see './symphony-external-relay-centos-<version>.x86_64/gemalto_jsp_6.2.2/readme.txt' for more information
- ./symphony-external-relay-centos-<version>.x86_64/gemalto_jsp_6.3+ -> see './symphony-external-relay-centos-<version>.x86_64/gemalto_jsp_6.3+/readme.txt' for more information
- ./symphony-external-relay-centos-<version>.x86_64/lib -> contains all libraries required for key manager's operation
- ./symphony-external-relay-centos-<version>.x86_64/sbin -> contains key manager's start and stop script
- ./symphony-external-relay-centos-<version>.x86_64/temp -> temp secure storage for the key manager process

Updating key manager? (First key manager installation? Please see the next section of this readme.)
To update key manager binaries and libraries:
1. Backup configuration folder /opt/keymanager/conf
2. Optionally, backup folder with log files /opt/keymanger/logs
3. Remove /opt/keymanager folder
4. Copy ./symphony-external-relay-centos-<version>.x86_64/ -> /opt/keymanager/
5. If you are using Gemalto client version 6.2.2 or higher, follow instructions in a corresponding readme file either under /opt/keymanager/gemalto_jsp_6.2.2 or
   /opt/keymanager/gemalto_jsp_6.3+ folder.
6. Refer to Key Manager installation guide to ensure no new configuration parameters have been implemented.
7. Verify the ownership and files' permissions before starting keymanager.

First Key Manager installation?
Default Key Manager path is '/opt/keymanager'. Ensure that all directories listed above are moved into the appropriate path.
Your final key manager setup should look like this:
- /opt/keymanager/bin
- /opt/keymanager/conf
- /opt/keymanager/gemalto_jsp_6.2.2
- /opt/keymanager/gemalto_jsp_6.3+
- /opt/keymanager/lib
- /opt/keymanager/sbin
- /opt/keymanager/temp
Follow Key Manager installation guide to perform initial key manager configuration setup.

