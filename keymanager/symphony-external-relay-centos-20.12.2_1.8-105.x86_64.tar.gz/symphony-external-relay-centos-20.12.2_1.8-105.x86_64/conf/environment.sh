#!/usr/bin/env bash

KEYMANAGER_HOME="/opt/keymanager"
LOG_DIR="${KEYMANAGER_HOME}/logs"
JAVA_HOME="/opt/jdk"
KEYMANAGER_OPTS="-server -Xms5048m -Xmx5048m \
-Djava.io.tmpdir=$KEYMANAGER_HOME/temp \
-Djava.library.path=$KEYMANAGER_HOME/native/ \
-Dcom.symphony.keymanager.home=$KEYMANAGER_HOME \
-Dcom.symphony.keymanager.sdk.maxtotalconnections=2000 \
-Dcom.symphony.keymanager.sdk.maxconnectionsperroute=1000 \
-Dcom.symphony.km.resourceMonitoringIntervalMs=10000 \
-Dcom.symphony.km.stressedPercentage=80 \
-Dcom.symphony.km.relaxedPercentage=60 \
-Dsymphony.cloud.logging.enableRemote=true \
-Dsymphony.cloud.logging.cloudLoggerLevel=INFO \
-Dservice.properties=$KEYMANAGER_HOME/conf/keymanager.properties \
-Dspring.config.location=file:$KEYMANAGER_HOME/conf/keymanager.properties \
-Dlog4j.configurationFile=$KEYMANAGER_HOME/conf/log4j2.xml \
-Djava.util.logging.manager=org.apache.logging.log4j.jul.LogManager \
-Dserver.tomcat.accesslog.directory=$LOG_DIR \
-Dmax.threads=2000 \
-Daccess.control.allow.origin=symphony.com,keymanager.domain \
-Dsession.cookie.domain=.change.to.full.keymanager.domain \
-Dreceiver.pool.size=16 \
-Duser.timezone=Etc/GMT \
-Dhost.name=change.it.to.full.server.host.name"
PATH=$JAVA_HOME/bin:$JAVA_HOME/bin/jre:$PATH
