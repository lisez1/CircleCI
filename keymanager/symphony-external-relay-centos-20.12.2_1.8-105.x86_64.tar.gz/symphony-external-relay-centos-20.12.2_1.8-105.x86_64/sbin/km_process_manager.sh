# Warning: This file is meant to be sourced by BASH scripts.
# It was not meant to be executed or sourced by other shells.

# use the [j]ava token so that grep process doesn't show in the grep output
KM_PATTERN="[j]ava.*com.symphony.keymanager.*javaagent:.*bin/relay-standalone.war"

# Outputs the PID of the KM, if running. Outputs nothing if KM process is not running.
# Returns 0 if function ran successfully, otherwise returns a non-zero value.
function get_km_pid() {
  local ps_cols
  local ps_status

  TMP_IFS=$IFS
  # in 'ps', only output PID then CMD in that order
  IFS=" " read -r -a ps_cols <<<"$(ps -o pid,cmd -fU ${UID} | grep "${KM_PATTERN}")"
  ps_status=${PIPESTATUS[0]}
  IFS=$TMP_IFS

  if [[ ${ps_status} -eq 0 ]]; then
    echo "${ps_cols[0]}"
    return 0
  fi

  return ${ps_status}
}

# Prints given message into stderr and exits script with status code 1
function echo_fatal_error() {
  (echo >&2 -e "$1")
  exit 1
}
