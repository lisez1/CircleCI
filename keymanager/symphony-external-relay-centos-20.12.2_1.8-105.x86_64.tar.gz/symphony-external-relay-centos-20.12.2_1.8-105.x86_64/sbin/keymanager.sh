#!/usr/bin/env bash

# Note: this script is deprecated.
# Please use start.sh to start Key Manager.

$(dirname $0)/start.sh
