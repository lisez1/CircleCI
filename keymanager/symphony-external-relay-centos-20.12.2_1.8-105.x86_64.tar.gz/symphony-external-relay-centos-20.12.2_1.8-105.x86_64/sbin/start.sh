#!/usr/bin/bash

ROOTDIR="$(dirname $0)/.."
LIBDIR="${ROOTDIR}/lib"
CONFDIR="${ROOTDIR}/conf"
KEYMANAGER="${ROOTDIR}/bin/relay-standalone.war"
MAIN_CLASS="org.springframework.boot.loader.WarLauncher"

source "${ROOTDIR}/sbin/km_process_manager.sh"
KM_PID=$(get_km_pid) || echo_fatal_error "Error starting Key Manager: unable to check if it is already running"

if [[ ! -z "${KM_PID}" ]]; then
  echo_fatal_error "Key Manager is already running under PID='${KM_PID}'"
fi

source ${CONFDIR}/environment.sh
STARTUP_LOG="${LOG_DIR}/km_startup.log"
mkdir -p ${LOG_DIR}

echo "Starting Key Manager; to view an intialization log, please refer to '${STARTUP_LOG}'."
nohup ${JAVA_HOME}/bin/java ${KEYMANAGER_OPTS} -javaagent:${KEYMANAGER} -cp ${KEYMANAGER}:${CONFDIR}:${LIBDIR}/* ${MAIN_CLASS} >$STARTUP_LOG 2>&1 &
echo "Key Manager started with PID='$!'"
