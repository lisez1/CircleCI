#!/usr/bin/bash

ROOTDIR="$(dirname $0)/.."
TEMP_DIR="${ROOTDIR}/temp"

source "${ROOTDIR}/sbin/km_process_manager.sh"
KM_PID=$(get_km_pid) || echo_fatal_error "Error stopping Key Manager: Unable to automatically detect Key Manager PID"

if [[ -z "${KM_PID}" ]]; then
  echo_fatal_error "Key Manager is not running!"
fi

echo "Stopping Key Manager - PID='${KM_PID}' ..."
kill -9 ${KM_PID}

echo "Removing temporary files from ${TEMP_DIR} ..."
rm -rf ${TEMP_DIR:?}/*
