#!/bin/bash

# Default directories. These values may change based on auto detection on user input
LUNA_HOME="/usr/safenet/lunaclient"
KM_HOME="/opt/keymanager"
WENGER_HOME="/data/utils"

# Used for logging, cannot contain spaces
KM_NAME="Key-Manager"
WENGER_NAME="Wenger"

# JVM parameter that will be replaced
JAVA_PATH_JVM_ARG="Djava.library.path="
SYMPHONY_LIB_PATH_JVM_ARG="Dsymphony.custom.library.path="

# File names of libraries distributed along with Symphony products (Key Manager and Wenger)
KM_HSM_LUNA_5_JAR="hsm-luna-5-*.jar"
KM_LUNA_PROVIDER_JAR="lunaprovider-*.jar"
KM_JC_PROVIDER_JAR="jcprovider-*.jar"

# Relative path of Key Manager installation directories and files
# They will be prependend with $KM_HOME after it's discovered
KM_JARS="lib"
KM_NATIVE="native"
KM_INIT_SCRIPT="conf/environment.sh"

# Relative path of Wenger installation directories and files
# They will be prependend with $WENGER_HOME after it's discovered
WENGER_JARS="lib"
WENGER_NATIVE="native"
WENGER_INIT_SCRIPT="sbin/wenger.sh"
WENGER_HSM_LUNA_7_JAR_PATH="gemalto_jsp_6.3+/hsm-luna-7-*.jar"
WENGER_HSM_LUNA_7_INSTALLATION_STEPS="gemalto_jsp_6.3+/readme.txt"

# Relative path of Luna Client provided libraries
# They will be prependend with $LUNA_HOME after it's discovered
LC_LUNA_PROVIDER_JAR="jsp/lib/LunaProvider.jar"
LC_LUNA_PROVIDER_SO="jsp/lib/libLunaAPI.so"
LC_JC_PROVIDER_JAR="jcprov/lib/jcprov.jar"
LC_JC_PROVIDER_SO="jcprov/lib/libjcprov.so"

# Prints given message into stderr and returns error
function echo_stderr() {
    local MSG=$1
    local ERR_CODE=1
    (>&2 echo -e ${MSG})
    return ${ERR_CODE}
}

# Checks whether file or directory exists and is readable
function file_or_dir_is_readable() {
    local PATH_TO_CHECK=$1;

    local RET_CODE=1 # error by default
    if [[ -r "$PATH_TO_CHECK" ]]; then
        RET_CODE=0;
    fi;

    return ${RET_CODE}
}

# Checks whether file or directory exists and is writable
function file_or_dir_is_writable() {
    local PATH_TO_CHECK=$1;

    local RET_CODE=1 # error by default
    if [[ -w "$PATH_TO_CHECK" ]]; then
        RET_CODE=0;
    fi;

    return ${RET_CODE}
}

# Checks whether file or directory exists and is readable
# Logs error if parameter is passed and file is not readable
function file_or_dir_is_readable_log() {
    local PATH_TO_CHECK=$1;
    file_or_dir_is_readable ${PATH_TO_CHECK} || echo_stderr "ERROR - No read access to $PATH_TO_CHECK";
}

# Checks whether file or directory exists and is writable
# Logs error if parameter is passed and file is not writable
function file_or_dir_is_writable_log() {
    local PATH_TO_CHECK=$1;
    file_or_dir_is_writable ${PATH_TO_CHECK} || echo_stderr "ERROR - No write access to $PATH_TO_CHECK";
}

# Checks if KM is installed in default location. If it's isn't, prompts user for KM path
# Also sets variables that depend on $KM_HOME
function find_km_installation_dir() {
    if ! file_or_dir_is_readable ${KM_HOME} ; then
        echo -e "\nUnable to automatically find Key Manager installation directory"
        read -p "Insert Key Manager installation path: " KM_HOME &&
        file_or_dir_is_readable ${KM_HOME} ||
        { echo_stderr "ERROR $KM_HOME does not exist or is inaccessible"; return 1; }
    fi

    echo "Successfully found Key Manager installation directory: $KM_HOME"
    KM_JARS="$KM_HOME/$KM_JARS" &&
    KM_NATIVE="$KM_HOME/$KM_NATIVE" &&
    KM_INIT_SCRIPT="$KM_HOME/$KM_INIT_SCRIPT"
}

# Checks if Wenger is installed in default location. If it isn't, prompts user for Wenger path.
# Also sets variables that depend on $WENGER_HOME
function find_for_wenger_installation_dir() {
        if ! file_or_dir_is_readable ${WENGER_HOME} ; then
        echo -e "\nUnable to automatically find Wenger installation directory"
        read -p "Insert Wenger installation path: " WENGER_HOME &&
        file_or_dir_is_readable ${WENGER_HOME} ||
        { echo_stderr "ERROR $WENGER_HOME does not exist or is inaccessible"; return 1; }
    fi

    echo "Successfully found Wenger installation directory: $WENGER_HOME"
    WENGER_JARS="$WENGER_HOME/$WENGER_JARS"
    WENGER_NATIVE="$WENGER_HOME/$WENGER_NATIVE"
    WENGER_INIT_SCRIPT="$WENGER_HOME/$WENGER_INIT_SCRIPT"
    WENGER_HSM_LUNA_7_JAR_PATH="$WENGER_HOME/$WENGER_HSM_LUNA_7_JAR_PATH"
}

# Attempts to infer Luna Client installation directory. If unable to do so, prompts user for such path.
# Also sets variables that depend on $LUNA_HOME
function find_luna_installation_dir() {

    # Definitions used for inferring luna client installation directory
    local DEFAULT_LUNA=${LUNA_HOME}
    local CMU_PATH=$(which cmu 2>/dev/null)
    local CHRYSTOKI_PATH="/etc/Chrystoki.conf"
    local TOOLS_DIR=$(grep -Po 'ToolsDir = \K[^;]*' ${CHRYSTOKI_PATH} 2>/dev/null)

    echo -e "\nAttempting to automatically find Luna Client installation directory"
    if file_or_dir_is_readable ${DEFAULT_LUNA} ; then
        LUNA_HOME=${DEFAULT_LUNA}
    elif file_or_dir_is_readable ${CMU_PATH} ; then
        LUNA_HOME=$(echo ${CMU_PATH} | awk -F '/bin' '{print $1}')
    elif file_or_dir_is_readable ${TOOLS_DIR} ; then
        LUNA_HOME=$(echo ${TOOLS_DIR} | awk -F '/bin' '{print $1}')
    else
        echo -e "\nUnable to automatically find Luna client installation directory"
        read -p "Insert Luna client installation path: " LUNA_HOME &&
        file_or_dir_is_readable ${LUNA_HOME} ||
        { echo_stderr "ERROR $LUNA_HOME does not exist or is inaccessible"; return 1; }
    fi

    echo "Successfully found Luna client installation directory: $LUNA_HOME"
    LC_LUNA_PROVIDER_JAR="$LUNA_HOME/jsp/lib/LunaProvider.jar"
    LC_LUNA_PROVIDER_SO="$LUNA_HOME/jsp/lib/libLunaAPI.so"
    LC_JC_PROVIDER_JAR="$LUNA_HOME/jcprov/lib/jcprov.jar"
    LC_JC_PROVIDER_SO="$LUNA_HOME/jcprov/lib/libjcprov.so"
}


function validate_all_requirements() {

    echo -e "\nChecking all requirements for installation..."

    local RET_CODE=0; # Success by default

    # Check if we can read all necessary files from Luna Client installation directory
    file_or_dir_is_readable_log ${LC_LUNA_PROVIDER_JAR} || RET_CODE=1;
    file_or_dir_is_readable_log ${LC_LUNA_PROVIDER_SO} || RET_CODE=1;
    file_or_dir_is_readable_log ${LC_JC_PROVIDER_JAR} || RET_CODE=1;
    file_or_dir_is_readable_log ${LC_JC_PROVIDER_SO} || RET_CODE=1;

    # Check if we can read Symphony's Luna Client 6.3+ specific dependency
    file_or_dir_is_readable_log ${WENGER_HSM_LUNA_7_JAR_PATH} || RET_CODE=1;

    # Check if we can write to all necessary Key Manager directories and files
    file_or_dir_is_writable_log ${KM_JARS} || RET_CODE=1;
    mkdir -p ${KM_NATIVE} && file_or_dir_is_writable_log ${KM_NATIVE} || RET_CODE=1;
    file_or_dir_is_writable_log ${KM_INIT_SCRIPT} || RET_CODE=1;

    # Check if we can write to all necessary Wenger directories and files
    file_or_dir_is_writable_log ${WENGER_JARS}  || RET_CODE=1;
    mkdir -p ${WENGER_NATIVE}  && file_or_dir_is_writable_log ${WENGER_NATIVE} || RET_CODE=1;
    file_or_dir_is_writable_log ${WENGER_INIT_SCRIPT} || RET_CODE=1;

    # Check if init scripts are valid
    grep -q ${JAVA_PATH_JVM_ARG} ${KM_INIT_SCRIPT} || { echo_stderr "ERROR: invalid ${KM_INIT_SCRIPT}"; RET_CODE=1; }
    grep -q ${JAVA_PATH_JVM_ARG} ${WENGER_INIT_SCRIPT} ||
        { echo_stderr "ERROR: invalid ${WENGER_INIT_SCRIPT}"; RET_CODE=1; }

    if [[ "$RET_CODE" -eq "0" ]]; then
        echo -e "All requirements are OK!"
    fi

    return ${RET_CODE}
}

# Installs default Safenet libraries
function install_libs() {
    local APP_NAME=$1
    local JARS_DIR=$2
    local NATIVE_DIR=$3

    echo -e "\nInstalling libraries into $APP_NAME..." &&
    cp -v ${LC_LUNA_PROVIDER_JAR}   ${JARS_DIR} &&
    cp -v ${LC_JC_PROVIDER_JAR}     ${JARS_DIR} &&
    cp -v ${WENGER_HSM_LUNA_7_JAR_PATH}             ${JARS_DIR} &&
    cp -v ${LC_LUNA_PROVIDER_SO}    ${NATIVE_DIR} &&
    cp -v ${LC_JC_PROVIDER_SO}      ${NATIVE_DIR} &&
    echo "Libraries installed into $APP_NAME successfully!" ||
    echo_stderr "ERROR installing libraries into $APP_NAME"
}

# Removes old Safenet custom libraries that are delivered by Symphony
function remove_custom_libs() {
    local APP_NAME=$1
    local JARS_DIR=$2

    echo -e "\nRemoving old libraries from $APP_NAME..." &&
    rm -vf ${JARS_DIR}/${KM_HSM_LUNA_5_JAR} &&
    rm -vf ${JARS_DIR}/${KM_LUNA_PROVIDER_JAR} &&
    rm -vf ${JARS_DIR}/${KM_JC_PROVIDER_JAR} &&
    echo "Old libraries removed from $APP_NAME successfully!" ||
    echo_stderr "ERROR removing custom libraries from $APP_NAME"
}

# Updates script that initiates application with updated JVM argument
function update_init_script() {
    local INIT_SCRIPT=$1
    echo -e "\nUpdating library path argument in $INIT_SCRIPT file"
    sed -i "s/$JAVA_PATH_JVM_ARG/$SYMPHONY_LIB_PATH_JVM_ARG/g" ${INIT_SCRIPT}
    echo "$INIT_SCRIPT updated successfully!"
}

# Display execution warning and prompts for confirmation
function confirmation_warning() {
    echo "This script will install Safenet provided libraries into Key Manager and Wenger."
    echo "In this process, some files distributed by Symphony will be changed or removed."
    echo "Do you wish to continue with this installation?"
    select choice in "Yes" "No"; do
        case ${choice} in
            Yes ) echo "Starting installation..."; break;;
            No ) echo "Aborting installation"; exit 1;;
            *) echo "Please choose 1 or 2";;
        esac
    done
}

# Execution starts here
confirmation_warning &&
find_km_installation_dir &&
find_for_wenger_installation_dir &&
find_luna_installation_dir &&
validate_all_requirements &&
install_libs ${KM_NAME} ${KM_JARS} ${KM_NATIVE} &&
remove_custom_libs ${KM_NAME} ${KM_JARS} &&
update_init_script ${KM_INIT_SCRIPT} &&
install_libs ${WENGER_NAME} ${WENGER_JARS} ${WENGER_NATIVE} &&
remove_custom_libs ${WENGER_NAME} ${WENGER_JARS} &&
update_init_script ${WENGER_INIT_SCRIPT} &&
echo -e "\nSuccess! $WENGER_NAME and $KM_NAME are now ready to run alongside Luna Client v6.3+" ||
echo_stderr "\nERROR installing libs.
    \nPlease follow manual configuration instructions in $WENGER_HSM_LUNA_7_INSTALLATION_STEPS provided with Wenger installation";
