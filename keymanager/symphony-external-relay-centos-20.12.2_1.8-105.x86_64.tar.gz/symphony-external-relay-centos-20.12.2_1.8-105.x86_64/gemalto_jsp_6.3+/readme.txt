This file is provided by Symphony and is to be used with Gemalto (Safenet) HSM Client version 6.3.0 and up:
hsm-luna-7-*.jar (* is wildcard for KM version)

These files are provided by Gemalto/Safenet as part of Luna client and are to be used with HSM Client version 6.3 and up:
libLunaAPI.so - by default located in /usr/safenet/lunaclient/jsp/lib/.
LunaAPI.jar - by default located in /usr/safenet/lunaclient/jsp/lib/.
libjcprov.so - by default located in /usr/safenet/lunaclient/jcprov/lib/.
jcprovider.jar - by default located in /usr/safenet/lunaclient/jcprov/lib/.

Wenger and Key Manager must be properly configured to work along with Gemalto (Safenet) HSM Client version 6.3.0 and up.
This configuration can be done either manually or automatically, using provided script.

╔══════════════════════════════════════════════════════╗
║ AUTOMATIC CONFIGURATION: both Key Manager and Wenger ║
╚══════════════════════════════════════════════════════╝
Symphony provides a script for configuring Key Manager and Wenger for use with Gemalto (Safenet)
HSM Client version 6.3.0 and up: libs_installer.sh.
Simply run the script without any arguments and follow the prompts.

╔═══════════════════════════════════╗
║ MANUAL CONFIGURATION: Key Manager ║
╚═══════════════════════════════════╝
1. libLunaAPI.so and libjcprov.so must be copied to the folder with other native libraries.
   By default, it's /opt/keymanager/native .
2. LunaProvider.jar and jcprov.jar provided by Safenet must be copied to the folder with other Symphony's jar files.
   By default, it's /opt/keymanager/lib.
3. hsm-luna-7-*.jar must be copied to the folder with other Symphony's jar files.
   By default, it's /opt/keymanager/lib.
   Important note:
     Default distribution of Key Manager already contains the following files:
      /opt/keymanager/lib/hsm-luna-5-*.jar,
      /opt/keymanager/lib/lunaprovider-5.1.2.jar, and
      /opt/keymanager/lib/jcprovider-5.3.7.jar.
     They must be removed after step 2 and 3.
4. Add new 'symphony.custom.library.path' JVM parameter to environment.sh.
   The value of this parameter must point to a folder used in step 1 ( by default, /opt/keymanager/native ).

╔═══════════════════════════════════╗
║ MANUAL CONFIGURATION: Wenger tool ║
╚═══════════════════════════════════╝
1. Safenet's libLunaAPI.so and libjcprov.so must be copied to the folder with other native libraries.
   By default, it's <wenger_root>/native . If it does not exist, then it must be created.
2. Safenet's LunaProvider.jar and jcprov.jar must be copied to the folder with other Symphony's jar files.
   By default, it's <wenger_root>/lib for Wenger tool.
3. hsm-luna-7-*.jar must be copied to the folder with other Symphony's jar files.
   By default, it's <wenger_root>/lib for Wenger tool.
   Important note:
     Default distribution of Key Manager already contains the following files:
       <wenger_root>/lib/hsm-luna-5-*.jar,
       <wenger_root>/lib/lunaprovider-5.1.2.jar, and
       <wenger_root>/lib/jcprovider-5.3.7.jar.
     They must be removed after step 2 and 3.

4. Update <wenger_root>/sbin/wenger.sh file to use a new 'symphony.custom.library.path' JVM parameter.
For this modify the line that defines VMARGS variable.
If the default folder <wenger_root>/native was used in step 1 then the changes should look like this:
//this is original entry
VMARGS="-DenableRemote=false -d64 -Xms2g -Xmx4g -Djava.io.tmpdir=/tmp -Dlog.dir=$LOGDIR -Djava.library.path=$CRYPTOLIBPATH"

//this is the updated line
VMARGS="-DenableRemote=false -d64 -Xms2g -Xmx4g -Djava.io.tmpdir=/tmp -Dlog.dir=$LOGDIR -Dsymphony.custom.library.path=$CRYPTOLIBPATH"
