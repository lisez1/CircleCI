#!/usr/bin/env bash

# ===== Customise from here =====

outDir=/tmp/rsa                         # The output directory for the public/private key pair
privateKeyName=privatekey.pem           # The output filename of the private key
pubKeyName=pubkey.pem                   # The output filename of the public key
keyType=pkcs8                           # The key encoding: pkcs1 or pkcs8

# ===== Customise to here =====

printf "Creating $keyType key pair\n"

function genPKSC1 {
    openssl genrsa -out "${outDir}/${privateKeyName}" 4096
    openssl rsa -in "${outDir}/${privateKeyName}" -pubout -out "${outDir}/${pubKeyName}"
}

function genPKCS8 {
    openssl genrsa -out "${outDir}/privatekey.tmp" 4096
    openssl req -newkey rsa:4096 -x509 -subj "/C=US/ST=CA/L=Palo Alto/O=Symphony LLC/CN=Symphony Bot" -key "${outDir}/privatekey.tmp" -out "${outDir}/publickey.tmp"
    openssl pkcs8 -topk8 -nocrypt -in "${outDir}/privatekey.tmp" -out "${outDir}/${privateKeyName}"
    openssl x509 -pubkey -noout -in "${outDir}/publickey.tmp" > "${outDir}/${pubKeyName}"
    rm "${outDir}/privatekey.tmp"
    rm "${outDir}/publickey.tmp"
}

case ${keyType} in
    "pkcs1")
        genPKSC1
        ;;
    "pkcs8")
        genPKCS8
        ;;
esac

printf "Public key written to ${outDir}/${pubKeyName}\n"
printf "Private key written to ${outDir}/${privateKeyName}\n"