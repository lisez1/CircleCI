# Symphony API Agent


## Prerequisites

1. Install latest OpenJDK 8 (https://openjdk.java.net/install/).
    - **Note:** make sure you have installed the OpenJDK 8 update 161 or later, otherwise, the Java JCE will also be needed. 
        - In case needed: `Java JCE` (http://www.oracle.com/technetwork/java/javase/downloads/jce8-download-2133166.html).


## Download

Download the Agent package from https://rest-api.symphony.com/docs/agent and unzip it in a directory of your choice. 
The following example shows a particular package being unzipped:

```bash
unzip agent-VERSION.zip 
Archive:  agent-VERSION.zip
   creating: resources/
   creating: resources/certs/
   creating: resources/rsa/
   creating: util/
  inflating: startup.sh
  inflating: util/jwt-helper-HELPER_VERSION.jar 
  inflating: resources/Postman.json 
  inflating: util/setup-VERSION.jar  
  inflating: resources/README.md 
  inflating: util/diagnostics-VERSION.jar 
  inflating: agent.yml           	
  inflating: resources/agent-api-public.yaml 
  inflating: resources/certs/agentservice.p12 
  inflating: resources/certs/int-key.pem 
  inflating: resources/certs/ceservice.p12 
  inflating: resources/certs/int-cert.p12 
  inflating: resources/certs/bot.user1.p12 
  inflating: resources/rsa/privatekey.pem 
  inflating: resources/rsa/pubkey.pem 
  inflating: util/create_rsa.sh  	
  inflating: util/create_cert.sh 	
  inflating: agent-VERSION.jar    
  inflating: util/jcurl-JCURL_VERSION.jar  
```

The Agent distribution package contains:

* The Agent server package (`agent-VERSION.jar`)
* A configuration helper package (`util/setup-VERSION.jar`)
* [JCurl](https://github.com/symphonyoss/JCurl) - a `curl(1)` replacement with native support for PKCS12 certificates and JSON
* Sample of Agent configuration file (`resources/agent.yml`)
* The Agent API Swagger specification (`resources/agent-api-public.yaml`)
* Test certificates for the required service users (`resources/certs/agentservice.p12` and `resources/certs/ceservice.p12`)
* Test user certificate for calling the Agent API (`resources/certs/bot.user1.p12`). Note that this user needs to be created first and have its certificate or its signing certificate imported in the pod)
* Test signing certificate and its private key for generating user certs (`resources/certs/int-cert.p12` and `resources/certs/int-key.pem`)
* A shell script to create a certificate signed by the user-provided signing cert (`util/create_cert.sh`)  
* Test RSA public/private key pair: for calling the Agent API (`resources/rsa/privatekey.pem` and `resources/rsa/pubkey.pem`). Note that you must create the user first and import their public RSA key into the pod.
* Sample Postman collection: contains predefined calls for testing the Agent installation (`resources/Postman.json`).
* `jwt-helper`: a helper tool to generate a JWT authentication token (signed by the provided private RSA key) for the provided username. (`util/jwt-helper.jar`).
    - Run as `java -jar jwt-helper.jar -user <username> -key <privatekey.pem>`. The output is a short-lived (5 minutes) token which can be used in the payload of the RSA authentication requests.


## Configuration

Modify the included configuration template (`agent.yml`) to match your environment:

```yaml
# Adjust the value agent.podName to an identifier for your pod
agent:
  podName: acme

# Adjust the section agent.url to point to your pod and Key Manager
  url:
    symphony: https://acme.symphony.com
    pod: https://acme.symphony.com/pod
    agent: https://acme.symphony.com/agent
    login: https://acme.symphony.com/login
    firehose: https://acme.symphony.com/firehose
    keymanager: https://acme.symphony.com/relay
    register: https://acme.symphony.com/appstore/v1/internal/mgmt/agent/register
    sessionauth: https://acme.symphony.com/sessionauth
    keyauth: https://acme.symphony.com:8444/keyauth

# Indicates if Symphony Elements are enabled to be sent via the Agent messaging APIs. Default: true
  features:
    elements:
      enabled: true

# Adjust the value of agent.endpoints.deprecated.disable as true if you don't want accounts to be able to use our deprecated APIs.
# PS: A Warning header stating that the endpoint is deprecated will be added into each response to a deprecated endpoint if this setting is false.
  endpoints:
    deprecated:
      disable: false

# Adjust the section agent.certificate to match the paths to your certificates for the users agentservice and ceservice when using certificate authentication for them;
# If you do not have certificates configured for those users, please contact Symphony support for guidance into creating certificates signed by your Certificate Authority
# A test signing certificate ("Disposable Test Intermediate Certificate Authority", int-cert.pem) and a bot certificate signed by that CA (bot.user1.p12) are provided to help during development; the password for both certificates is "changeit".
  certificate:
    agentservice:
      file: /home/acme/agentservice.p12
      password: changeit
      type: pkcs12
    ceservice:
      type: pkcs12
      file: /home/acme/ceservice.p12
      password: changeit

# Adjust the section agent.privateKey if you want to setup agentservice and ceservice users using RSA authentication.
# The Public RSA Key (associated to the private one) must be imported for both users on the AC Portal User Management UI.
# We provide one RSA key pair that can be used for testing and development purposes.
  privateKey:
    agentservice:
      file: /data/agent/certs/agentservice.pem

    ceservice:
      file: /data/agent/certs/ceservice.pem


# Adjust the section agent.proxy to point to your proxy, if in use; if you don't use a proxy to connect to Symphony or the Keymanager, delete that section. 
# The property  certAuth.enable controls whether calls to the certificate authentication endpoints (/sessionauth and /keyauth, typically deployed at port 8444) should go through the proxy as well
  proxy:
    symphony:
      username: user
      password: changeit
      uri: https://proxy.acme.com
    keymanager:
      uri: https://proxy.acme.com
      password: changeit
      username: user
    firehose:
      uri: https://proxy.acme.com
      username: user
      password: changeit
    certAuth:
      enabled: false

# the remaining configuration properties are set to reasonable defaults and can be left unmodified, unless otherwise desired
```

The sections `podName` and `url` are required at all times. 

Also, you have to choose between using one of the authentication options, so `privateKey` or `certificate` sections are also required.
  
All other config properties are optional.

**Note:** When using certificate-based authentication configuration, users *agentservice* and *ceservice* require their certificates or their signing certificate to be imported in the pod.

## Running

1. For testing purposes, you can run the Agent on the default port (9443), with a supplied test server certificate and using the system Java truststore.
`java -jar agent-VERSION.jar --agent.config=agent.yml`

2. For production deployments, create a custom startup.sh script such as:

```bash
java \
-Dlogs.directory=/var/logs/agent \
-jar agent-VERSION.jar \
--agent.config=config.yaml \
--server.port=443 \
--server.ssl.key-store=/home/acme/keystore.jks \
--server.ssl.key-store-password=changeit \
--server.ssl.key-password=changeit
```

If you require to trust a pod certificate that is not in the Java `cacerts` file, include:

```bash
--server.ssl.trust-store=/home/acme/truststore.jks \
--server.ssl.trust-store-password=changeit 
```

### Configuring TLS 1.2
The Agent supports TLS 1.2 by default, but also allows lower versions of TLS protocol to be used.  To restrict the Agent
to only accept TLS 1.2 and strong cipher suites, add the following arguments on your `startup.sh` script:

```bash
--server.ssl.enabled-protocols="TLSv1.2" \
--server.ssl.protocol="TLS" \
--server.ssl.ciphers="TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA"
```

### Logging

If you want to set DEBUG log level for console and agent.log, set your execution with the following environment variable: ```-DlogLevel=DEBUG```

If you want to provide custom logging configuration, include the following program argument:

```bash
--logging.cofig=/home/acme/log4j2.xml
```

**Note:** The recommendation is for this argument to be used only if really needed, as the current log format is made in a way to help the Agent Team to provide support for it.


#### Logging Rotation
Agent has 3 log files it usually work with: `agent.log` `agent-error.log` and `agent-metrics.log`.

Agent has a logging rotation strategy set by default to keep up to 10 local files and each file can have a max file size of 100 MB.

When a file "rotates", it will be automatically zipped and renamed with a number at the end, corresponding to how many times it rotated already, with the number increment stopping at the file limits.

Example:
```shell script
agent-1.log.gz
agent-2.log.gz
agent-error-1.log.gz
agent-error-2.log.gz
agent-metrics-1.log.gz
agent-metrics-2.log.gz
```

Logging rotation can be customized for all 3 files by setting the following VM Options:
```shell script
-DmaxLogFiles=20
-DlogFileSizeLimit="500 MB"
```
With the above, all 3 agent log files will rotate (independently) when one hits 500 MB in "unzipped" size, and will keep up to 20 files, always keeping the latest ones and discarding the older ones if it goes beyond the file limit.

To further customize these parameters for each log file independently, the following can be used (it also demonstrates the syntax for sizes):

agent.log:
```shell script
-Dagent.maxLogFiles=5
-Dagent.logFileSizeLimit="2 GB"
```
agent-error.log:
```shell script
-Derror.maxLogFiles=15
-Derror.logFileSizeLimit=800MB
```
agent-metrics.log:
```shell script
-Dmetrics.maxLogFiles=20
-Dmetrics.logFileSizeLimit=500KB
```

The parameters presented above can be combined in any configuration, with the more specific parameters taking precedence over the general one.

The following example uses all parameters presented until now, but note that the first 2, the more general ones, will be useless in this configuration because all others are being specified: 
```shell script
java -DmaxLogFiles=20 -DlogFileSizeLimit="500 MB" -Dagent.maxLogFiles=5 -Dagent.logFileSizeLimit="2 GB" -Derror.maxLogFiles=15 -Derror.logFileSizeLimit=800MB -Dmetrics.maxLogFiles=20 -Dmetrics.logFileSizeLimit=500KB -jar agent.jar --agent.config=<your-agent-config>.yml
```

The previous command will have the same effect as the command bellow:
```shell script
java -Dagent.maxLogFiles=5 -Dagent.logFileSizeLimit="2 GB" -Derror.maxLogFiles=15 -Derror.logFileSizeLimit=800MB -Dmetrics.maxLogFiles=20 -Dmetrics.logFileSizeLimit=500KB -jar agent.jar --agent.config=<your-agent-config>.yml
```

**Note:** Keep in mind that none of these needs to be set, this is just for customization.

## Setup script

The Agent distribution includes a setup helper script to create a custom configuration and generate certificates.
Launch the script with `java -jar util/setup-VERSION.jar`.

```bash
java -jar setup-VERSION.jar 
```

```
-------------- Agent Configuration Generation--------------
[a]  View current configuration
[b]  Configure base URL (Symphony URL)
[c]  Configure required properties
[d]  Configure proxies
[e]  Generate user certificate

[f]  Write configuration

[q]  Quit

Enter selection:  
```

```
Enter selection:  b


-------------- Symphony URL [e.g., https://acme.symphony.com] --------------
Provide a valid Symphony URL and press enter or type 'q' to return to previous menu:
https://localhost.symphony.com:8443
```

```
Enter selection:  a
-------------- Agent Configuration --------------


Pod name                                  : local
Symphony URL                              : https://localhost.symphony.com:8443
Agent URL                                 : https://localhost.symphony.com:9443/agent
Pod URL                                   : https://localhost.symphony.com:8443/pod
Session authentication URL                : https://localhost.symphony.com:8444/sessionauth
Keymanager URL                            : https://localhost.symphony.com:8443/relay
Keymanager authentication URL             : https://localhost.symphony.com:8444/keyauth
Login URL                                 : https://localhost.symphony.com:8443/login
Firehose URL                              : https://localhost.symphony.com/firehose-2
Agent registration URL                    : https://localhost.symphony.com:8443/appstore/v1/internal/mgmt/agent/register

Agentservice certificate                  : null
Agentservice password                     : null
Agentservice certificate type             : pkcs12
Ceservice certificate                     : null
Ceservice password                        : null
Ceservice certificate type                : pkcs12

Symphony proxy URI                        : null
Symphony proxy username                   : null
Symphony proxy password                   : null
Keymanager proxy URI                      : null
Keymanager proxy username                 : null
Keymanager proxy password                 : null
Firehose proxy URI                        : null
Firehose proxy username                   : null
Firehose proxy password                   : null
Enable proxy for authentication endpoints : false
```

```
Enter selection:  c


-------------- Modify Agent Configuration --------------
[a]  Configure pod name                           [local]

[b]  Configure Symphony URL                       [https://localhost.symphony.com:8443]
[c]  Configure Agent API URL                      [https://localhost.symphony.com:9443/agent]
[d]  Configure pod API URL                        [https://localhost.symphony.com:8443/pod]
[e]  Configure session authentication URL         [https://localhost.symphony.com:8444/sessionauth]
[f]  Configure keymanager URL                     [https://localhost.symphony.com:8443/relay]
[g]  Configure keymanager authentication URL      [https://localhost.symphony.com:8444/keyauth]
[h]  Configure login URL                          [https://localhost.symphony.com:8443/login]
[i]  Configure Firehose URL                       [https://localhost.symphony.com/firehose-2]
[j]  Configure Agent registration URL             [https://localhost.symphony.com:8443/appstore/v1/internal/mgmt/agent/register]

[k]  Configure Agentservice certificate file      [null]
[l]  Configure Agentservice certificate password  [null]
[m]  Configure Agentservice certificate type      [pkcs12]
[n]  Configure Ceservice certificate file         [null]
[o]  Configure Ceservice certificate password     [null]
[p]  Configure Ceservice certificate type         [pkcs12]

[q]  Return to main menu
```

```
Enter selection:  d


-------------- Modify Agent Proxy Configuration --------------
[a]  Configure Symphony proxy URI               [null]
[b]  Configure Symphony proxy username          [null]
[c]  Configure Symphony proxy password          [null]

[d]  Configure keymanager proxy URI             [null]
[e]  Configure keymanager proxy username        [null]
[f]  Configure keymanager proxy password        [null]

[g]  Configure Firehose proxy URI               [null]
[h]  Configure Firehose proxy username          [null]
[i]  Configure Firehose proxy password          [null]

[j]  Configure proxying authentication requests [false]

[q]  Return to main menu
```

```
Enter selection:  e


-------------- Generate user certificate --------------
[a]  Provide a signing certificate [e.g., /home/symphony/int-cert.p12]                [null]
[b]  Provide signing certificate password [e.g., 'changeit']                          [null]
[c]  Provide a pem certificate [e.g., /home/symphony/int-key.pem]                     [null]
[d]  Provide pem certificate password [e.g., 'changeit']                              [null]
[e]  Configure target certificate user name [e.g., agentservice]                      [null]
[f]  Provide the desired password for your certificate [e.g., changeit]               [null]
[g]  Configure certificate output directory [e.g., /home/symphony]                    [null]

[h]  Generate certificate

[q]  Return to main menu
```

```
Enter selection:  f


-------------- Write Configuration --------------
[a]  Configure output directory [null]
[b]  Configure output file type [properties/yaml] [YAML]
[c]  Write agent configuration file 

[q]  Return to main menu
```

## Debugging (Actuator) endpoints
The Agent server includes a number of Actuator endpoints providing debugging information.

In the cloud setup the actuator endpoints are disabled by default, and in onprem setups it has the `health` and `register` endpoints enabled by default.

All actuator endpoints are password-protected and are configured on a separate port, with `10443` as the default value.
The port can be overridden by setting the property `--management.server.port=<value>` when starting the Agent application.

### Security

The security username and password can be set by launching the Agent with: `--spring.security.user.name=admin --spring.security.user.password=password`. 
If not set, the security password is automatically generated by the application. Check the Agent startup logs to find 
the generated value :

```
2019-10-31T12:05:39,442 INFO  [main] UserDetailsServiceAutoConfiguration#  - 

Using generated security password: <password-value>
```

### Endpoints

Here's the list of available actuator endpoint for the Agent application : 

| Name       	| Activated 	        | Description                                 	| Path                          | Method | Activation flag                                  |  
|------------	|---------------------- |---------------------------------------------	|------------------------------ |--------|------------------------------------------------- |   
| `actuator`    | :white_check_mark:    | List of all enabled endpoints                 | `/agent/actuator`             | `GET`  |                                                  |
| `register`   	| :white_check_mark:    | Agent re-registration                       	| `/agent/actuator/register`    | `POST` |                                                  |
| `health`     	| :white_check_mark:    | Displays your application’s health status   	| `/agent/actuator/health`      | `GET`  |                                                  |
| `info`       	| :black_square_button: | Displays information about your application 	| `/agent/actuator/info`        | `GET`  | `--management.endpoint.info.enabled=true`        |
| `env`        	| :black_square_button: | Displays current environment properties     	| `/agent/actuator/env`         | `GET`  | `--management.endpoint.env.enabled=true`         |
| `threaddump` 	| :black_square_button: | Performs a thread dump                      	| `/agent/actuator/threaddump`  | `GET`  | `--management.endpoint.threaddump.enabled=true`  |
| `heapdump`   	| :black_square_button: | Returns a GZip compressed JVM heap dump     	| `/agent/actuator/heapdump`    | `GET`  | `--management.endpoint.heapdump.enabled=true`    |
| `metrics`   	| :black_square_button: | Micrometer metrics                         	| `/agent/actuator/metrics`     | `GET`  | `--management.endpoint.metrics.enabled=true`     |
| `prometheus`  | :black_square_button: | Prometheus scrapping endpoint                	| `/agent/actuator/prometheus`  | `GET`  | `--management.endpoint.prometheus.enabled=true`  |
          
> Paths above are relative to the management URL : https://agent-server.symphony.com:10443